package com.esprit.pidevbackend.Domain;

public enum Happy {
	HAPPY_HOUR,HAPPY_DAYS,BLACK_FRIDAY,PROMOTION

}
